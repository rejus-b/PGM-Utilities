#ifndef PGMA2BFUNC
#define PGMA2BFUNC

int a2b(pgm *pgmStruct, char *fileName);


#endif