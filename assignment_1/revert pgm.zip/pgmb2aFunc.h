#ifndef PGMB2AFUNC
#define PGMB2AFUNC

int b2a(pgm *pgmStruct, char *outputFileName);


#endif