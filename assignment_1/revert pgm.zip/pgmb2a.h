#ifndef PGMB2AFUNC
#define PGMB2AFUNC

int main(int argc, char **argv);

int pgmStructInit(pgm *pgmStruct);


#endif
