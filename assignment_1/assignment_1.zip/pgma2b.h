#ifndef PGMA2B
#define PGMA2B


int main(int argc, char **argv);

int pgmStructInit(pgm *pgmStruct);


#endif