#ifndef OPENWRITEFILE
#define OPENWRITEFILE

int writeFile(char *fileName, pgm *pgmStruct);


#endif